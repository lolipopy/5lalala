package dev.edu.javaee.spring.aop.support;

import dev.edu.javaee.spring.aop.Pointcut;

public class JdkRegexpMethodPointcutAdvisor extends AbstractPointcutAdvisor {

	@Override
	public Pointcut getPointcut() {
		// TODO Auto-generated method stub
		return null;
	}

}
