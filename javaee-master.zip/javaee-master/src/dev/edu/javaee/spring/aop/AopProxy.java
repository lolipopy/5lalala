package dev.edu.javaee.spring.aop;

public interface AopProxy {
	Object getProxy();
}
