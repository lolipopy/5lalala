package dev.edu.javaee.spring.aop;

public interface Advisor {
	Advice getAdvice();
}
