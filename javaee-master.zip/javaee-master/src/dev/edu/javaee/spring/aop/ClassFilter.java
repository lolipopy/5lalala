package dev.edu.javaee.spring.aop;

public interface ClassFilter {
	boolean matches(Class<?> cls);
}
