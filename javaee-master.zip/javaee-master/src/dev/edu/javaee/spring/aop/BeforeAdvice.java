package dev.edu.javaee.spring.aop;

public interface BeforeAdvice extends Advice {
	
}
